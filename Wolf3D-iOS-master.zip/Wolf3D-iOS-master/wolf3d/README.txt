WOLF3D iOS v2.1 GPL source release
===============================================

This file contains the following sections:

GENERAL NOTES
LICENSE

GENERAL NOTES
=============

WOLF3D iOS v2.1 is a free release, and can be downloaded from
http://idsoftware.com/idstuff/wolf3d/wolf3d_ios_v21_src.zip

This source release does not contain any game data, the game data remains subject to the original EULA and applicable law.


LICENSE
=======

See COPYING.txt for the GNU GENERAL PUBLIC LICENSE.  If COPYING.txt does not accompany, write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

