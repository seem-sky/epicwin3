
extern	id	keypairview_i;

@interface KeypairView:View
{
}

- calcViewSize;

#define	SPACING		4
#define	FONTSIZE	12
#define	EXTRASPC	2

#define	LINEHEIGHT	16

@end
